<?php
    require ('Inc/essentials.php');
    unset($_SESSION['ma_tk_nv']);
    redirect("login.php");
?>