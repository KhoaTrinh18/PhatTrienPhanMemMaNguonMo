<link rel="stylesheet" href="Public/vendors/mdi/css/materialdesignicons.min.css">
<link rel="stylesheet" href="Public/vendors/flag-icon-css/css/flag-icon.min.css">
<link rel="stylesheet" href="Public/vendors/css/vendor.bundle.base.css">
<link rel="stylesheet" href="Public/vendors/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" href="Public/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
<link rel="stylesheet" href="Public/css/style.css">
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.css" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
    .custom-cell {
        max-width: 200px;
        overflow-wrap: break-word;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
    }
    label {
        font-size: 15px;
        font-weight: normal;
    }
</style>
