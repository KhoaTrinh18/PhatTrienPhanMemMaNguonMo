<script src="Public/vendors/js/vendor.bundle.base.js"></script>
<script src="Public/vendors/chart.js/Chart.min.js"></script>
<script src="Public/vendors/jquery-circle-progress/js/circle-progress.min.js"></script>
<script src="Public/js/off-canvas.js"></script>
<script src="Public/js/hoverable-collapse.js"></script>
<script src="Public/js/misc.js"></script>
<script src="Public/js/dashboard.js"></script>
<script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script>
    let table = new DataTable('#myTable');
    let table1 = new DataTable('#myTable1');
</script>