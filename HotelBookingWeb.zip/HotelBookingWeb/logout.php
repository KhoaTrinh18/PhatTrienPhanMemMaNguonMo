<?php
    require('Admin/Inc/essentials.php');
    unset($_SESSION['ma_tk_kh']);
    redirect("index.php");
?>